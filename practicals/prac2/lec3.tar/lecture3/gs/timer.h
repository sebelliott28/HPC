
/* header file for simple wall clock timer */

double timer( void );
